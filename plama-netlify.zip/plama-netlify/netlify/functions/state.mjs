// API de sincronización de app_plama_admin (Netlify Functions + Netlify Blobs).
// GET  /api/state?rev=N  -> estado completo (o { same: true } si no hay cambios)
// POST /api/state        -> { ops: [...] } aplica cambios por campo y devuelve el estado
// PIN opcional: define la variable de entorno APP_PIN en Netlify.
import { getStore } from "@netlify/blobs";

export const config = { path: "/api/state" };

const KEY = "state";
const TOOLS = ["garrucha", "separadores", "jaladores", "machetes", "palas", "palines", "trinches", "botiquines", "bajantes", "cascos"];
const okId = (id) => typeof id === "string" && /^[A-Za-z0-9_]{1,80}$/.test(id);
const str = (v, n = 300) => String(v ?? "").slice(0, n);
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });

const emptyDoc = () => ({ rev: 0, seeded: false, workers: {} });

function cleanWorker(w, id) {
  const tools = {};
  if (w && typeof w.tools === "object" && w.tools) {
    TOOLS.forEach((t) => { if (w.tools[t]) tools[t] = true; });
  }
  return {
    name: str(w.name), code: str(w.code, 40), doc: str(w.doc, 40),
    task: str(w.task), itinerary: str(w.itinerary),
    tools, delivered: !!w.delivered, ts: Number(w.ts) || Date.now(),
  };
}

// Devuelve true si el documento cambió
function applyOp(doc, op) {
  if (!op || typeof op !== "object") return false;
  const W = doc.workers;
  switch (op.t) {
    case "seed": {
      if (doc.seeded || !Array.isArray(op.workers)) return false;
      op.workers.slice(0, 500).forEach((w) => {
        if (w && w.name && okId(w.id)) W[w.id] = cleanWorker(w, w.id);
      });
      doc.seeded = true;
      return true;
    }
    case "addw": {
      if (!okId(op.id) || !op.name) return false;
      doc.seeded = true;
      if (W[op.id]) return false; // ya existe: no se pisa lo que otro dispositivo editó
      W[op.id] = cleanWorker({ name: op.name, code: op.code, doc: op.doc, ts: op.ts }, op.id);
      return true;
    }
    case "field": {
      const w = W[op.id];
      if (!w) return false;
      if (op.f === "task" || op.f === "itinerary") { w[op.f] = str(op.v); return true; }
      if (op.f === "delivered") { w.delivered = !!op.v; return true; }
      return false;
    }
    case "tool": {
      const w = W[op.id];
      if (!w || !TOOLS.includes(op.tool)) return false;
      if (op.v) w.tools[op.tool] = true; else delete w.tools[op.tool];
      return true;
    }
    case "clearTools": {
      const w = W[op.id];
      if (!w) return false;
      w.tools = {};
      return true;
    }
    case "del": {
      if (!W[op.id]) return false;
      delete W[op.id];
      return true;
    }
    case "reset": {
      Object.values(W).forEach((w) => { w.task = ""; w.itinerary = ""; w.tools = {}; w.delivered = false; });
      return true;
    }
    default:
      return false;
  }
}

export default async (req) => {
  const pin = process.env.APP_PIN;
  if (pin && req.headers.get("x-pin") !== pin) return json({ error: "pin" }, 401);

  const store = getStore("plama");

  if (req.method === "GET") {
    const entry = await store.getWithMetadata(KEY, { type: "json", consistency: "strong" });
    const doc = (entry && entry.data) || emptyDoc();
    const since = Number(new URL(req.url).searchParams.get("rev"));
    if (entry && since === doc.rev) return json({ same: true, rev: doc.rev, seeded: doc.seeded });
    return json({ rev: doc.rev, seeded: doc.seeded, workers: doc.workers });
  }

  if (req.method === "POST") {
    let body;
    try { body = await req.json(); } catch { return json({ error: "bad json" }, 400); }
    const ops = Array.isArray(body.ops) ? body.ops.slice(0, 600) : [];

    // Cada cambio se reaplica sobre la versión más reciente; si otro dispositivo
    // escribió en medio, se reintenta (no se pierden cambios de otros).
    for (let attempt = 0; attempt < 8; attempt++) {
      const entry = await store.getWithMetadata(KEY, { type: "json", consistency: "strong" });
      const doc = (entry && entry.data) || emptyDoc();
      let changed = false;
      ops.forEach((op) => { if (applyOp(doc, op)) changed = true; });
      if (!changed) return json({ rev: doc.rev, seeded: doc.seeded, workers: doc.workers });
      doc.rev += 1;
      const opts = entry ? { onlyIfMatch: entry.etag } : { onlyIfNew: true };
      const res = await store.setJSON(KEY, doc, opts);
      if (res.modified) return json({ rev: doc.rev, seeded: doc.seeded, workers: doc.workers });
      await new Promise((r) => setTimeout(r, 40 + Math.random() * 120));
    }
    return json({ error: "busy" }, 503);
  }

  return json({ error: "method" }, 405);
};
